# -*- coding:utf-8 -*-
# bayes learning
# bayes princple

from numpy import *


# create data for analyse
def loadDataSet():
    postingList = [['my', 'dog', 'has', 'flea', 'problems', 'help', 'please'],
                   ['maybe', 'not', 'take', 'him', 'to', 'dog', 'park', 'stupid'],
                   ['my', 'dalmation', 'is', 'so', 'cute', 'I', 'love', 'him'],
                   ['stop', 'posting', 'stupid', 'worthless', 'garbage'],
                   ['mr', 'licks', 'ate', 'my', 'steak', 'how', 'to', 'stop', 'him'],
                   ['quit', 'buying', 'worthless', 'dog', 'food', 'stupid']]
    classVec = [0, 1, 0, 1, 0, 1]  # class labels
    return postingList, classVec


# The sample space is transformed into a word dictionary
def createVocabList(dataSet):
    vocabSet = set([])
    for document in dataSet:
        vocabSet = vocabSet | set(document)  # Set operation
    return list(vocabSet)


# Each sample of the sample space is transformed into a word vector
# Word set model, record each feature appears as "1"
def setOfWords2Vec(vocabList, inputSet):
    returnVec = [0] * len(vocabList)
    for word in inputSet:
        if word in vocabList:
            returnVec[vocabList.index(word)] = 1
            # The position containing the feature is set to 1
        else:
            print "the word: %s is not in the Vocabulary!" % word
    return returnVec


# The word bag model records the number of occurrences of each feature
def bagofWords2VecMn(vocabList, inputSet):
    returnVec = [0] * len(vocabList)
    for word in inputSet:
        if word in vocabList:
            returnVec[vocabList.index(word)] += 1
            # records the number of occurrences of each feature
        else:
            print "the word: %s is not in Vocabulary!" % word
    return returnVec


# The probability that each feature is located in each category is counted
def trainNB0(trainMatrix, trainCategory):
    numTrainDocs = len(trainMatrix)  # number of sample
    numWords = len(trainMatrix[0])  # number of vacablory
    pAbusive = sum(trainCategory) / float(numTrainDocs)  # The probability that the sample tag is "1"
    # p0Num=zeros(numWords);p1Num=zeros(numWords)  # Count the number of occurrences of each feature
    p0Num = ones(numWords);
    p1Num = ones(numWords)  # Laplacian smoothing
    p0Denom = 2.0;
    p1Denom = 2.0  # The total number of occurrences of all features
    for i in range(numTrainDocs):
        if trainCategory[i] == 1:
            p1Num += array(trainMatrix[i])  # numpy operation
            p1Denom += sum(trainMatrix[i])
        else:
            p0Num += array(trainMatrix[i])
            p0Denom += sum(trainMatrix[i])
    # p1Vect=p1Num/p1Denom  # The probability of each feature with the tag "1"
    # p0Vect=p0Num/p0Denom  # The probability of each feature with the tag "0"
    p1Vect = log(p1Num / p1Denom)
    p0Vect = log(p0Num / p0Denom)

    return p0Vect, p1Vect, pAbusive


# Bayes Classification of Unknown Variables
def classifyNB(vec2Classify, p0Vec, p1Vec, pAbusive):
    p1 = sum(vec2Classify * p1Vec) + log(pAbusive)  # P(c=1|x)
    p0 = sum(vec2Classify * p0Vec) + log(1 - pAbusive)  # P(c=0|x)
    if p1 > p0:
        return 1
    else:
        return 0


# test unknown for label
def testingNB():
    list0Posts, listClasses = loadDataSet()
    myVocabList = createVocabList(list0Posts)
    trainMat = []
    for postinDoc in list0Posts:
        trainMat.append(setOfWords2Vec(myVocabList, postinDoc))
    p0v, p1v, pAb = trainNB0(trainMat, listClasses)
    testEntry = ['love', 'my', 'dalmation']
    thisDoc = array(setOfWords2Vec(myVocabList, testEntry))
    print testEntry, 'classified as: ', classifyNB(thisDoc, p0v, p1v, pAb)


if __name__ == '__main__':
    # dataSet,labels=loadDataSet()
    # vocabList=createVocabList(dataSet)
    # trainMat=[]
    # for i in range(len(dataSet)):
    #     trainMat.append(setOfWords2Vec(vocabList,dataSet[i]))
    # p0V,p1V,pAb=trainNB0(trainMat,labels)
    # print p0V
    # print p1V
    # print pAb
    testingNB()
