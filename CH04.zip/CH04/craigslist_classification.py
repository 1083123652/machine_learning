# craigslist classification by bayes

import feedparser
import Text_garbage_classification
import bayes
import random
from numpy import *


# using for RSS resoures

# Get high frequency vocabulary
def calcMostFreq(vocabList, fullText):
    import operator
    freqDict = {}
    for token in vocabList:
        freqDict[token] = fullText.count(token)
    sortedFreq = sorted(freqDict.items(), key=operator.itemgetter(1), reverse=True)
    return sortedFreq[:30]


def localWords(feed1, feed0):
    docList = []
    classList = []
    fullText = []
    minLen = min(len(feed1['entries']), len(feed0['entries']))  # sample number,Contains multiple entries
    # read dataSet and labels
    for i in range(minLen):
        wordList = Text_garbage_classification.textParse(feed1['entries'][i]['summary'])
        docList.append(wordList)
        fullText.append(wordList)
        classList.append(1)
        wordList = Text_garbage_classification.textParse(feed0['entries'][i]['summary'])
        docList.append(wordList)
        fullText.append(wordList)
        classList.append(0)
    # obtain the vocabList
    vocabList = bayes.createVocabList(docList)
    top30Words = calcMostFreq(vocabList, fullText)  # obtain high frequency vocabulary
    for pairW in top30Words:
        if pairW[0] in vocabList:
            vocabList.remove(pairW[0])
    trainingSet = range(2 * minLen)  # training sample index set
    testSet = []  # testing sample index set
    for i in range(20):
        randIndex = int(random.uniform(0, len(trainingSet)))
        testSet.append(trainingSet[randIndex])  # obtain the testing sample index set
        del trainingSet[randIndex]
    trainMat = []  # training sample vectors
    trainClasses = []  # training sample labels
    for docIndex in trainingSet:
        trainMat.append(bayes.bagofWords2VecMn(vocabList, docList[docIndex]))
        trainClasses.append(classList[docIndex])
    # Obtain the probability based on the training sample
    p0v, p1v, pAb = bayes.trainNB0(array(trainMat), trainClasses)
    errorCount = 0.0
    for docIndex in testSet:
        wordVector = bayes.setOfWords2Vec(vocabList, docList[docIndex])
        if bayes.classifyNB(wordVector, p0v, p1v, pAb) != classList[docIndex]:
            errorCount += 1
    print 'the error rate is: ', float(errorCount) / len(testSet)
    return vocabList, p0v, p1v


def getTopWords(ny, sf):
    import operator
    vocabList, p0v, p1v = localWords(ny, sf)  # Get feature probabilities and dictionaries
    topNY = []
    topSF = []
    for i in range(len(p0v)):
        if p0v[i] > -6.0: topSF.append((vocabList[i], p0v[i]))
        if p1v[i] > -6.0: topNY.append((vocabList[i], p1v[i]))
    sortedSF = sorted(topSF, key=lambda pair: pair[1], reverse=True)
    print "SF_____________________________________"
    for item in sortedSF:
        print item[0]
    sortedNY = sorted(topNY, key=lambda pair: pair[1], reverse=True)
    print "NY_____________________________________"
    for item in sortedNY:
        print item[0]


if __name__ == '__main__':
    ny = feedparser.parse('http://newyork.craigslist.org/stp/index.rss')
    sf = feedparser.parse('http://sfbay.craigslist.org/stp/index.rss')
    getTopWords(ny, sf)
