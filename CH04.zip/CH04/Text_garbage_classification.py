# -*- coding;utf-8 -*-

import os
import re
import bayes
import random


# The text is converted to a character vector, and non-characters are removed
def textParse(bigString):
    listOfTokens = re.split(r'\W*', bigString)
    return [tok.lower() for tok in listOfTokens if len(tok) > 2]


def spamTest():
    docList = []  # Word list
    classList = []  # label list
    fullText = []  # List of backup words
    # Gets all the file names under that path
    trainingFileList = os.listdir(r'D:\Python_data\machine\CH04\email\ham')
    print trainingFileList
    m = len(trainingFileList)
    for i in range(m):
        # read the file and textParse
        wordList = textParse(open(r'D:\Python_data\machine\CH04\email\ham\%s' % trainingFileList[i]).read())
        docList.append(wordList)
        fullText.append(wordList)
        classList.append(0)  # class label define

    # Gets all the file names under that path
    trainingFileList1 = os.listdir(r'D:\Python_data\machine\CH04\email\spam')
    print trainingFileList1
    n = len(trainingFileList1)
    for i in range(n):
        # read the file and textParse
        wordList = textParse(open(r'D:\Python_data\machine\CH04\email\spam\%s' % trainingFileList1[i]).read())
        docList.append(wordList)
        fullText.append(wordList)
        classList.append(1)  # class label define

    # Word dictionary by createVocabList
    vocabList = bayes.createVocabList(docList)
    trainingSet = range(m + n)  # training sample index set
    testSet = []  # testing sample index set
    for i in range(10):
        randIndex = int(random.uniform(0, len(trainingSet)))
        testSet.append(trainingSet[randIndex])  # obtain the testing sample index set
        del trainingSet[randIndex]
    trainMat = []  # training sample vectors
    trainClasses = []  # training sample labels
    for docIndex in trainingSet:
        trainMat.append(bayes.setOfWords2Vec(vocabList, docList[docIndex]))
        trainClasses.append(classList[docIndex])
    # Obtain the probability based on the training sample
    p0v, p1v, pAb = bayes.trainNB0(trainMat, trainClasses)
    errorCount = 0.0
    for docIndex in testSet:
        wordVector = bayes.setOfWords2Vec(vocabList, docList[docIndex])
        if bayes.classifyNB(wordVector, p0v, p1v, pAb) != classList[docIndex]:
            errorCount += 1
    print 'the error rate is: ', float(errorCount) / len(testSet)


if __name__ == "__main__":
    spamTest()
