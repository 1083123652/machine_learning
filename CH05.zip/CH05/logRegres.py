# -*- coding:utf-8 -*-
# logisitic claaification

from numpy import *
from urllib2 import urlopen
import re

# read dataSet and its labels
def loadDataSet(filename):
    dataMat = []  # dataset data
    labelMat = []  # label of data
    with open(filename) as f:
        content = f.readlines()
    for line in content:
        lineArr = line.strip().split()  # Remove line breaks and split data
        dataMat.append([1.0, float(lineArr[0]), float(lineArr[1])])  # 1.0 --- W0
        labelMat.append(int(lineArr[-1]))
    return dataMat, labelMat

# read data from url and transfotm into array struction
def readDataFromWeb(url):
    html=urlopen(url).read() # read data from url
    html=re.sub('\?',"0",html)  # Collate the defaults,replace with 0
    html=html.split('\n') # split data
    temphtml = html[0]
    m=len(html)-1  # the number of sample
    n=len(temphtml.split(' ')) # the number of character
    dataMat = zeros((m, n-1))  # sample array
    dataLabel=zeros(m)   # sample label array
    for i in range(m):
        if html[i]!='':
            tempData=html[i].strip().split(' ')
            dataMat[i,:]=tempData[0:-1]
            if int(tempData[-1])==2:
                tempData[-1]=0
            dataLabel[i]=tempData[-1]
    return dataMat,dataLabel # dataLabel-->row vector


# Normalized data
# (dataset-minvals)/(maxvals-minvals)
def autoNorm(dataSet):
    minVals=dataSet[tuple(dataSet.argmin(axis=0)),tuple(range(len(dataSet[0])))]
    maxVals=dataSet[tuple(dataSet.argmax(axis=0)),tuple(range(len(dataSet[0])))]
    ranges=maxVals-minVals
    normdataSet=zeros(shape(dataSet))
    m=dataSet.shape[0]
    normdataSet=dataSet-tile(minVals,(m,1))
    normdataSet=normdataSet/tile(ranges,(m,1))
    return normdataSet,ranges,minVals

# define sigmoid function
# from numpy import exp to operation numpy.array
def sigmoid(inX):
    return 1.0 / (1.0 + exp(-inX))


#  Gradient rise:θ_j≔θ_j+α∑_(i=1)^m (y^((i) )-h_θ (x^((i) ) ))x_j^((i))
# classLabels--->Row vector
def gradAscent(dataMatIn, classLables):
    dataMatrix = matrix(dataMatIn)
    labelMat = matrix(classLables).T  # Into a column vector
    m, n = shape(dataMatrix)
    alpha = 0.001  # Step size
    maxCycles = 500  # Cycles
    weights = ones((n, 1))  # Initialization weight -->column vector
    for k in range(maxCycles):
        # Weights are calculated cyclically based on the Batch Gradient Rise algorithm
        h = sigmoid(dataMatrix * weights)  # Matrix multiplication
        error = labelMat- h  # y^((i) )-h_θ (x^((i) )
        weights = weights + alpha * dataMatrix.transpose() * error
    return weights #column vector


# Random Gradient Rise Algorithm:θ_j≔θ_j+α(y^((i) )-h_θ (x^((i) ) ))x_j^((i))
# simpling Operation
# classLabels-->row vector
def stocGradAscent(dataMatIn,classLabels):
    dataArray=array(dataMatIn)
    m, n = shape(dataArray)
    alpha=0.01
    weights=ones((n,1)) # columm vector
    for i in range(m):
        h=sigmoid(sum(dataArray[i]*weights))
        error=classLabels[i]-h  # important point
        weights=weights+alpha*error*matrix(dataArray[i]).T
    return weights #column vector

# Improved Stochastic Gradient Rise Algorithm
# Solve small periodic fluctuations and faster convergence
# classLabels--->Row vector
def stocGradAscent1(dataMatIn,classLabels,numIter=150):
    dataArray=array(dataMatIn)
    m, n = shape(dataArray)
    weights=ones((n,1))
    for j in range(numIter):
        dataIndex=range(m)
        for i in range(m):
            alpha=4/(1.0+j+i)+0.01
            randIndex=int(random.uniform(0,len(dataIndex)))
            h=sigmoid(sum(dataArray[randIndex]*weights))
            error=classLabels[randIndex]-h  # important point
            weights=weights+alpha*error*matrix(dataArray[randIndex]).T
            del dataIndex[randIndex]
    return weights  #column vector

# Draw data and diversity lines
def plotBestFit(wei):
    import matplotlib.pyplot as plt
    weights = wei.getA()
    dataMat, labelMat = loadDataSet('testSet.txt')
    dataArr = array(dataMat)  # obtain dataSet,transform array
    n = shape(dataArr)[0]  # obtain the number of sample data
    xcord1 = []
    ycord1 = []  # The individual values of the data labeled 1 are
    xcord2 = []
    ycord2 = []  # The individual values of the data labeled 0 are
    for i in range(n):
        if int(labelMat[i]) == 1:
            xcord1.append((dataArr[i, 1]))
            ycord1.append(dataArr[i, 2])
        else:
            xcord2.append((dataArr[i, 1]))
            ycord2.append(dataArr[i, 2])
    fig=plt.figure()
    ax=fig.add_subplot(111)
    ax.scatter(xcord1,ycord1,s=30,c='red',marker='s')
    ax.scatter(xcord2,ycord2,s=30,c='green',marker='o')
    x=arange(-3.0,3.0,0.1)
    y=(-weights[0]-weights[1]*x)/weights[2]  # Draw a line for classification
    # w0+w1*x1+w2*x2=0;if it > 0 --> 1;else it < 0 -->0
    ax.plot(x,y)
    plt.xlabel('X1')
    plt.ylabel('X2')
    plt.show()


# classify function:logisitic/sigmoid
def classifyVector(inX,weights):
    prob=sigmoid(matrix(inX)*matrix(weights))
    if prob >= 0.5:
        return 1.0
    else:
        return 0.0

# getting data sample and test errorrate
def colicTest(trainUrl,testUrl):
    trainDataMat,trainLabel=readDataFromWeb(trainUrl)# train sample and label
    testDataMat,testLabel=readDataFromWeb(testUrl) # test sample and label
    normdataSet,ranges,minVals=autoNorm(trainDataMat)  # normalized data
    trainWeights=stocGradAscent1(normdataSet,trainLabel,1000)  # obtain the weights
    print trainWeights
    errorCount=0.0
    numTest=len(testDataMat)
    for i in range(numTest):
        if int(classifyVector(((testDataMat[i]-minVals)/ranges),trainWeights))!=int((testLabel[i])):
            errorCount+=1
    errorRate=(float(errorCount)/numTest)
    print "the error rate of this test is %f" % errorRate
    return errorRate



if __name__ == '__main__':
    # dataArr, labelMat = loadDataSet('testSet.txt')
    # weights1 = gradAscent(dataArr, labelMat)
    # print weights1
    # weights2=stocGradAscent1(dataArr,labelMat,1000)
    # print weights2
    # plotBestFit(weights1)
    # plotBestFit(weights2)
    # dataMat, dataLabel=readDataFromWeb('http://archive.ics.uci.edu/ml/machine-learning-databases/horse-colic/horse-colic.data')
    # normdataSet, ranges, minVals=autoNorm(dataMat)
    # print normdataSet
    colicTest('http://archive.ics.uci.edu/ml/machine-learning-databases/horse-colic/horse-colic.data',
              'http://archive.ics.uci.edu/ml/machine-learning-databases/horse-colic/horse-colic.test')
