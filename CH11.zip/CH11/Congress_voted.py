from votesmart import votesmart
votesmart.apikey='49024thereoncewasamanfromnantucket94040'
bills=votesmart.votes.getBillsByStateRecent(118080)
for bill in bills:
    print bill