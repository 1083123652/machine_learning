# coding:utf-8

import urllib
import json
from time import sleep
from numpy import *
import matplotlib.pyplot as plt
import kMeans


# # Gets the latitude and longitude of the location
# def geoGrab(stAddress,city):
#     apiStem='http://where.yahooapis.com/geocode?'  # api location
#     params={}
#     params['flags']='J'
#     params['appid']='dj0yJmk9OEZBY1F0OHA1bHBEJmQ9WVdrOVoxWTBlV0ZDTldFbWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD0wYQ--'
#     params['location']='%s %s' % (stAddress,city)
#     url_params=urllib.urlencode(params)  # string transfrom to url text
#     yahooApi=apiStem+url_params
#     print yahooApi
#     c=urllib.urlopen(yahooApi)  # connect the url
#     return json.load(c.read())  # read data and load to json

# Gets the latitude and longitude of the location
# def geoGrab(stAddress,city):
def geoGrab(city):
    apiStem='https://maps.googleapis.com/maps/api/geocode/json?'  # api location
    params={}
    params['key'] = 'AIzaSyBAnf1dxsFCCNFHOnySafKkxjnaVd4NVQo'
    # params['address']='%s %s' % (stAddress,city)
    params['address']='%s' % (city)
    url_params=urllib.urlencode(params)  # string transfrom to url text
    yahooApi=apiStem+url_params
    print yahooApi
    c=urllib.urlopen(yahooApi)  # connect the url
    return json.loads(c.read())  # read data and load to json

# Gets the latitude and longitude of all geographic locations in the file
def massPlaceFind(filename):
    fw=open('places1.txt','w+')
    for line in open(filename).readlines():
        line=line.strip()
        # lineArr=line.split('\t')
        # retDict=geoGrab(lineArr[1],lineArr[2])
        retDict = geoGrab(line)
        if retDict['status']=='OK':
            lat=float(retDict['results'][0]['geometry']['location']['lat'])
            lng=float(retDict['results'][0]['geometry']['location']['lng'])
            print line,lat,lng
            fw.write('%s\t%f\t%f\n' % (line,lat,lng))
        else:
            print "error fetching"
        sleep(1)
    fw.close()

# Spherical distance calculation
def distSLC(vecA,vecB):
    a=sin(vecA[0,1]*pi/180)*sin(vecB[0,1]*pi/180)
    b=cos(vecA[0,1]*pi/180)*cos(vecB[0,1]*pi/180)*cos(pi*(vecB[0,0]-vecA[0,0])/180)
    return arccos(a+b)*6371.0


# plot picture to show
def clusterClubs(numClust=5):
    datList=[]
    for line in open('places.txt').readlines():  # reading data
        lineArr=line.split('\t')
        datList.append([float(lineArr[-2]),float(lineArr[-1])])
    datMat=mat(datList)
    print len(datMat)
    myCentroids,clustAssing=kMeans.biKmeans(datMat,numClust,distMeas=distSLC)  # k-means operation
    x=[];y=[]
    for i in range(numClust):
        x.append(myCentroids[i][0,0])
        y.append(myCentroids[i][0,1])
    fig=plt.figure()
    rect=[0.1,0.1,0.8,0.8]
    scatterMarkets=['s','o','^','p','8','d','v','h','>','<']  # Data display graph
    axprops=dict(xticks=[],yticks=[])
    ax0=fig.add_axes(rect,label='ax0',**axprops)
    # imgP=plt.imread('Portland.png') # read image
    imgP=plt.imread('zhongguo.png') # read image
    ax0.imshow(imgP)  # show image
    ax1=fig.add_axes(rect,label='ax1',frameon=False)
    for i in range(numClust):
        ptsInCurrCluster=datMat[nonzero(clustAssing[:,0].A==i)[0],:]
        marketStyle=scatterMarkets[i % len(scatterMarkets)]  # Take more than,operation running
        ax1.scatter(ptsInCurrCluster[:,0].flatten().A[0],ptsInCurrCluster[:,1].flatten().A[0],marker=marketStyle,s=90)  # Draw data points and graphically represent clusters
    ax1.scatter(x,y,marker='+',s=300)  # Draw the centroid
    plt.show()





if __name__=='__main__':
    clusterClubs(4)
    # geoGrab('shenzhen','nanshan')
    # massPlaceFind('shenfen.txt')