# coding:utf-8
# unsupervised learning
# kmeans:Its performance is affected by the chosen distance calculation method
# SSE(sum of squared error): measures the clustering effect

from numpy import *


# read dataSet from file and transform into float type
def loadDataSet(filename):
    dataMat = []
    with open(filename) as f:  # to ensure that the initiative to close
        for line in f.readlines():
            curLine = line.strip().split('\t')
            fltLine = map(float, curLine)
            dataMat.append(fltLine)
    return dataMat  # list struction


# euclidean distance calculation for two vector
def distEclud(vecA, vecB):
    vecA = mat(vecA);
    vecB = mat(vecB)
    return sqrt(sum(power(vecA - vecB, 2)))


# construct the initial centroid
def randCent(dataSet, k):
    dataSet = mat(dataSet)
    n = shape(dataSet)[1]  # obtain the number of character
    centroids = mat(zeros((k, n)))  # construct the initial centroid
    for j in range(n):
        minJ = min(dataSet[:, j])  # obtain min number
        rangeJ = float(max(dataSet[:, j]) - minJ)  # gets the range of values for a feature
        centroids[:, j] = minJ + rangeJ * random.rand(k, 1)  # rand(k,1)-->Create a random number for the (k, 1) matrix
    return centroids


# K - means algorithm
# distMeas:distance calculation
# createCent: centroids create
def kMeans(dataSet, k, distMeas=distEclud, createCent=randCent):
    dataSet = mat(dataSet)
    m = shape(dataSet)[0]  # obtain the number of dataSet
    # each data point is recorded from the nearest centroid, its index, and the distance squared
    clusterAssment = mat(zeros((m, 2)))
    centroids = createCent(dataSet, k)  # create centroids
    clusterChanged = True  #
    while clusterChanged:
        clusterChanged = False
        for i in range(m):
            minDist = inf
            minIndex = -1
            for j in range(k):
                distJI = distMeas(dataSet[i, :], centroids[j, :])
                if distJI < minDist:
                    minDist = distJI
                    minIndex = j
            if clusterAssment[i, 0] != minIndex:
                clusterChanged = True
            clusterAssment[i, :] = minIndex, minDist ** 2
        # print centroids
        for cent in range(k):  # change the centroid position
            # all data points with a centroid of k are obtained
            ptsInClust = dataSet[nonzero(clusterAssment[:, 0].A == cent)[0]]
            centroids[cent, :] = mean(ptsInClust, axis=0)  # calculate the average
    return centroids, clusterAssment  # centroids and record


# divided k mean
# solve the k-means may converge to the local minimum,
#  rather than the global minimum
def biKmeans(dataSet, k, distMeas=distEclud):
    dataSet = mat(dataSet)
    m = shape(dataSet)[0]
    clusterAssment = mat(zeros((m, 2)))
    centroid0 = mean(dataSet, axis=0).tolist()[0]
    centList = [centroid0]
    for j in range(m):
        clusterAssment[j, 1] = distMeas(dataSet[j, :], mat(centroid0)) ** 2
    while (len(centList) < k):
        lowestSSE = inf
        for i in range(len(centList)):
            ptsInCurrCluster = dataSet[nonzero(clusterAssment[:, 0].A == i)[0], :]
            centroidMat, splitClustAss = kMeans(ptsInCurrCluster, 2, distMeas)
            sseSplit = sum(splitClustAss[:, 1])
            sseNotSplit = sum(clusterAssment[nonzero(clusterAssment[:, 0].A != i)[0], 1])
            print "sseSplit, and sseNotSplit: ", sseSplit, sseNotSplit
            if (sseSplit + sseNotSplit) < lowestSSE:
                bestCentToSplit = i
                bestNewCents = centroidMat
                bestClustAss = splitClustAss.copy()
        # The cluster is divided into two new clusters, one cluster index of the original cluster index,
        #  another new cluster index for a new index number
        bestClustAss[nonzero(bestClustAss[:, 0].A == 1)[0], 0] = len(centList)  # Give the new centroid an index
        bestClustAss[nonzero(bestClustAss[:, 0].A == 0)[0], 0] = bestCentToSplit  # Give the old centroid an index
        print "the bestCentToSplit is: ", bestCentToSplit
        print "the len of bestClustAss is: ", len(bestClustAss)
        centList[bestCentToSplit] = bestNewCents[0, :]  # update the old centroid to new centroid
        centList.append(bestNewCents[1, :])  # add another new centroid to cenlist
        clusterAssment[nonzero(clusterAssment[:, 0].A == bestCentToSplit)[0], :] = bestClustAss
    return centList, clusterAssment


if __name__ == "__main__":
    # datMat = loadDataSet('testSet.txt')
    datMat = loadDataSet('testSet2.txt')
    # centroids=randCent(datMat,4)
    # print centroids
    # print distEclud(datMat[0],datMat[1])
    # centroids, clusterAssment = kMeans(datMat, 4)
    # print centroids
    centList,clusterAssment=biKmeans(datMat,3)
    print centList
