# -*- coding:utf-8 -*-
# SVM learning

from numpy import *
import matplotlib.pyplot as plt

# read dataSet and class label
def loadDataSet(filename):
    dataMat=[] # sample dataSet
    labelMat=[]  # sample class label
    with open(filename) as f:  # read file with "with open"
        for line in f.readlines():
            lineArr=line.strip().split('\t')
            dataMat.append([float(lineArr[0]),float(lineArr[1])])
            labelMat.append(float(lineArr[2]))
    return dataMat,labelMat

# Random selection j!=i
def selectJrand(i,m):
    j=i
    while (j==i):
        j=int(random.uniform(0,m))
    return j


# Make sure that a is within the bounds
def clipAlpha(aj,H,L):
    if aj>H:
        aj=H
    if L>aj:
        aj=L
    return aj


# Coordinate rise method to update a and b
# ω=∑_(i=1)^m α_i y^((i)) x^((i))
def smoSimple(dataMatIn,classLabels,C,toler,maxIter):
    dataMatrix = mat(dataMatIn)  # dataSet transform into matrix
    labelMat = mat(classLabels).T # class label transform into column vector
    b = 0  # unknown data b for function wx+b
    m,n = shape(dataMatrix)
    alphas = mat(zeros((m,1)))  # create a to show w
    iter = 0 # the number of iter
    while (iter < maxIter):
        alphaPairsChanged = 0
        # Update the value of each a
        for i in range(m):
            fXi = float(multiply(alphas,labelMat).T*(dataMatrix*dataMatrix[i,:].T))+b  # f(x(i))=wx(i)+b ,Classification function for data classification calculation
            # error of predict: Ei=f(x(i))-Y(i)
            Ei = fXi-float(labelMat[i])
            if ((labelMat[i] * Ei < -toler) and (alphas[i] < C)) or ((labelMat[i] * Ei > toler) and (alphas[i] > 0)):
                j = selectJrand(i,m)
                fXj = float(multiply(alphas,labelMat).T * (dataMatrix * dataMatrix[j,:].T)) + b# f(x(j))=wx(j)+b ,Classification function for data classification calculation
                # error of predict: Ej=f(x(j))-Y(j)
                Ej = fXj - float(labelMat[j])
                alphaIold = alphas[i].copy() # old alpha[i]
                alphaJold = alphas[j].copy()  # old alpha[j]
                # Determine the range of a , L<a<H
                if (labelMat[i]!=labelMat[j]):
                    L=max((0,alphas[j]-alphas[i]))
                    H=min((C,C+alphas[j]-alphas[i]))
                else:
                    L = max((0, alphas[j] + alphas[i]-C))
                    H = min((C, alphas[j] + alphas[i]))
                if float(L)==float(H):
                    # print "H==L"
                    continue
                eta=2.0*dataMatrix[i,:]*dataMatrix[j,:].T-dataMatrix[i,:]*dataMatrix[i,:].T-dataMatrix[j,:]*dataMatrix[j,:].T
                if eta>=0:
                    print "eta>=0"
                    continue
                # α_j≔α_j-(y^((j) ) (E_i-E_j))/η
                # η=2〈x^i,x^j 〉-〈x^i,x^i 〉-〈x^j,x^j 〉
                alphas[j]-=labelMat[j]*(Ei-Ej)/eta
                alphas[j]=clipAlpha(alphas[j],H,L) # Determine the scope
                if (abs(alphas[j]-alphaJold)<0.00001):
                    # print "j not moving enough"
                    continue
                # α_i≔α_i+y^i y^j (α_j^old-α_j)
                alphas[i]+=labelMat[j]*labelMat[i]*(alphaJold-alphas[j])
                b1=b-Ei-labelMat[i]*(alphas[i]-alphaIold)*dataMatrix[i,:]*dataMatrix[i,:].T-labelMat[j]*(alphas[j]-alphaJold)*dataMatrix[i,:]*dataMatrix[j,:].T
                b2=b-Ej-labelMat[i]*(alphas[i]-alphaIold)*dataMatrix[i,:]*dataMatrix[j,:].T-labelMat[j]*(alphas[j]-alphaJold)*dataMatrix[j,:]*dataMatrix[j,:].T
                # update b for fx
                if (0<alphas[i]) and (C>alphas[i]):
                    b=b1
                elif (0<alphas[j]) and (C>alphas[j]):
                    b=b2
                else:
                    b=(b1+b2)/2.0
                alphaPairsChanged+=1  # Record the number of updates per inner loop a
                # print "iter: %d i: %d,pairs changed %d" % (iter,i,alphaPairsChanged)
        if (alphaPairsChanged == 0):
            iter += 1
        else:
            iter = 0
        # print "iteration number: %d" % iter
    return b, alphas

# Build the structure to save the message of data
class optStruct:
    def __init__(self,dataMatIn,classLabels,C,toler,kTup):
        self.X=dataMatIn
        self.labelMat=classLabels
        self.C=C
        self.tol=toler
        self.m=shape(dataMatIn)[0]
        self.alphas=mat(zeros((self.m,1)))
        self.b=0
        self.eCache=mat(zeros((self.m,2)))
        self.K=mat(zeros((self.m,self.m))) # the result of kernal function,stand for all <x,z>
        for i in range(self.m):  # k(x,x)
            self.K[:,i]=kernelTrans(self.X,self.X[i,:],kTup)

# kernal function-->K(x,xj)==k(x1,xj),k(x2,xj)...k(xm,xj)
def kernelTrans(X, A, kTup):
    m, n = shape(X)
    K = mat(zeros((m, 1)))
    # linear function
    if kTup[0] == 'lin':
        K = X * A.T
    # Radial basis function
    elif kTup[0] == 'rbf':
        for j in range(m):
            deltaRow = X[j, :] - A
            K[j] = deltaRow * deltaRow.T  # Sum of squares of distance
        K = exp(K / (-2 * kTup[1] ** 2))
    else:
        raise NameError('Houston We Have a Problem-- That Kernal is not recognized')
    return K

# Define the classification error of a data k
def calcEK(oS,k):
    # fXk=float(multiply(oS.alphas,oS.labelMat).T*(oS.X*oS.X[k,:].T))+oS.b
    fXk=float(multiply(oS.alphas,oS.labelMat).T*oS.K[:,k]+oS.b)
    Ek=fXk-float(oS.labelMat[k])
    return Ek

# Heuristic Method in Inner,which maximize |Ei-Ej| to choose j
# this is the second choice -heurstic, and calcs Ej
def selectJ(i,oS,Ei):
    maxK=-1  # best index
    maxDeltaE=0  # biggest of differ of error(i,j)
    Ej=0
    oS.eCache[i]=[1,Ei] # error cache
    # Matrix.A base array: Returns the array on which the matrix is based
    # Nonzeros (a) Returns the index(Row,Volumn) of the element of array a with a value other than zero
    # onzeros (a)[0] Returns the index(Row) of the element of array a with a value other than zero
    validEcacheList=nonzero(oS.eCache[:,0].A)[0]
    if (len(validEcacheList))>1:
        for k in validEcacheList:
            if k==i:continue
            Ek=calcEK(oS,k) # calc the error of data j
            deltaE=abs(Ei-Ek)  # Difference, to choose the max
            if (deltaE>maxDeltaE):
                maxK=k
                maxDeltaE=deltaE
                Ej=Ek
        return maxK,Ej
    else:
        # first iteration
        j=selectJrand(i,oS.m)
        Ej=calcEK(oS,j)
    return j,Ej


# update the error of data k
def  updateEk(oS,k):
    Ek=calcEK(oS,k)
    oS.eCache[k]=[1,Ek]

# Inner loop,Independent choice j ,as smoSimple
def innerL(i,oS):
    Ei=calcEK(oS,i)
    if ((oS.labelMat[i]*Ei<-oS.tol) and (oS.alphas[i] < oS.C )) or ((oS.labelMat[i]*Ei > oS.tol) and (oS.alphas[i] > 0)):
        j,Ej=selectJ(i,oS,Ei)
        alphasIold=oS.alphas[i].copy()
        alphasJold=oS.alphas[j].copy()
        if oS.labelMat[i]!=oS.labelMat[j]:
            L=max(0,oS.alphas[j]-oS.alphas[i])
            H=min(oS.C,oS.C+oS.alphas[j]-oS.alphas[i])
        else:
            L=max(0,oS.alphas[i]+oS.alphas[j]-oS.C)
            H=min(oS.C,oS.alphas[i]+oS.alphas[j])
        if L==H:
            print "L==H";
            return 0
        # eta=2*oS.X[i,:]*oS.X[j,:].T-oS.X[i,:]*oS.X[i,:].T-oS.X[j,:]*oS.X[j,:].T
        eta=2*oS.K[i,j]-oS.K[i,i]-oS.K[j,j]
        oS.alphas[j]-=oS.labelMat[j]*(Ei-Ej)/eta
        oS.alphas[j]=clipAlpha(oS.alphas[j],H,L)
        updateEk(oS,j)
        if (abs(oS.alphas[j]-alphasJold) < 0.00001):
            print "j not moving enough";return 0
        oS.alphas[i]+=oS.labelMat[i]*oS.labelMat[j]*(alphasJold-oS.alphas[j])
        updateEk(oS,i)
        # b1=oS.b-Ei-oS.labelMat[i]*(oS.alphas[i] - alphasIold)*(oS.X[i,:]*oS.X[i,:].T)-oS.labelMat[j]*(oS.alphas[j]-alphasJold)*(oS.X[i,:]*oS.X[j,:].T)
        b1=oS.b-Ei-oS.labelMat[i]*(oS.alphas[i] - alphasIold)*oS.K[i,i]-oS.labelMat[j]*(oS.alphas[j]-alphasJold)*oS.K[i,j]
        # b2=oS.b-Ej-oS.labelMat[i]*(oS.alphas[i] - alphasIold)*(oS.X[i,:]*oS.X[j,:].T)-oS.labelMat[j]*(oS.alphas[j]-alphasJold)*(oS.X[j,:]*oS.X[j,:].T)
        b2=oS.b-Ej-oS.labelMat[i]*(oS.alphas[i] - alphasIold)*oS.K[i,j]-oS.labelMat[j]*(oS.alphas[j]-alphasJold)*oS.K[j,j]
        if (0<oS.alphas[i]) and (oS.alphas[i]<oS.C):
            oS.b=b1
        elif (0<oS.alphas[j]) and (oS.alphas[j]<oS.C):
            oS.b=b2
        else:
            oS.b=(b1+b2)/2.0
        return 1
    else:
        return 0

# External circulation, independent choice i
# kTup[0]--> function name,kTup[1]-->α of Radial basis function
def smoP(dataMatIn,classLabels,C,toler,maxIter,kTup=('lin',0)):
    oS=optStruct(mat(dataMatIn),mat(classLabels).transpose(),C,toler,kTup)
    iter=0
    entireSet=True
    alphaPairsChanged=0  # Each cycle updates the data
    # Iteration termination condition:
    # Condition 1: reach max iteration
    # Condition 2: no alpha changed after going through all samples,
    # in other words, all alpha (samples) fit KKT condition
    while (iter<maxIter) and ((alphaPairsChanged>0) or entireSet):
        alphaPairsChanged=0
        # first iteration or alphaPairsChanged=0,update alphas over all training examples
        if entireSet:
            for i in range(oS.m):
                alphaPairsChanged+=innerL(i,oS)
            print "fullSet, iter: %d i: %d, pairs changed %d" % (iter,i,alphaPairsChanged)
            iter+=1
        # update alphas over examples where alpha is not 0 & not C (not on boundary)
        else:
            nonBoundIs=nonzero((oS.alphas.A>0)*(oS.alphas.A<C))[0]
            for i in nonBoundIs:
                alphaPairsChanged+=innerL(i,oS)
                print "non-bound, iter: %d i: %d, pairs changed %d" % (iter,i,alphaPairsChanged)
            iter+=1
        if entireSet:entireSet=False
        elif (alphaPairsChanged==0):entireSet=True
        print "iteration number: %d" % iter
    return oS.b,oS.alphas

# Solve the value of w
def calcWs(alphas,dataArr,classLabels):
    X=mat(dataArr)
    labelMat=mat(classLabels).transpose()
    m,n=shape(X)
    w=zeros((n,1))
    for i in range(m):
        w+=multiply(alphas[i]*labelMat[i],X[i,:].T)
    return w

def testRbf(k1=1.3):
    dataArr,labelArr=loadDataSet('testSetRBF.txt') # training sample
    b,alphas=smoP(dataArr,labelArr,200,0.0001,1000,('rbf',k1)) # obtain b,alphas
    dataMat=mat(dataArr)
    labelMat=mat(labelArr).transpose()
    svInd=nonzero(alphas.A>0)[0] # index of support vector
    sVs=dataMat[svInd]   # support vector
    labelSV=labelMat[svInd] # class label of support vector
    print "there are %d Support Vectors" % shape(sVs)[0]
    m,n=shape(dataMat)
    errorCount=0
    # if wx+b>0 --> label 1
    # if wx+b<0 --> label -1
    # using kernal function result
    for i in range(m):
        kernalEval=kernelTrans(sVs,dataMat[i,:],('rbf',k1))  # Dimensional transformation
        predict=kernalEval.T*multiply(labelSV,alphas[svInd])+b
        if sign(predict)!=sign(labelArr[i]):
            errorCount+=1
    print "the training error rate is: %f" % (float(errorCount)/m) # Training error rate
    dataArr, labelArr = loadDataSet('testSetRBF2.txt') # testing sample
    errorCount = 0
    dataMat = mat(dataArr)
    labelMat = mat(labelArr).transpose()
    m, n = shape(dataMat)
    # if wx+b>0 --> label 1
    # if wx+b<0 --> label -1
    # using kernal function result
    for i in range(m):
        kernalEval=kernelTrans(sVs,dataMat[i,:],('rbf',k1)) # Dimensional transformation
        predict=kernalEval.T*multiply(labelSV,alphas[svInd])+b
        if sign(predict)!=sign(labelArr[i]):
            errorCount+=1
    print "the training error rate is: %f" % (float(errorCount)/m) # testing error rate

def img2vector(filename):
    returnVect = zeros((1,1024))
    fr = open(filename)
    for i in range(32):
        lineStr = fr.readline()
        for j in range(32):
            returnVect[0,32*i+j] = int(lineStr[j])
    return returnVect


def loadImages(dirName):
    from os import listdir
    hwLabels = []
    trainingFileList = listdir(dirName)           #load the training set
    m = len(trainingFileList)
    trainingMat = zeros((m,1024))
    for i in range(m):
        fileNameStr = trainingFileList[i]
        fileStr = fileNameStr.split('.')[0]     #take off .txt
        classNumStr = int(fileStr.split('_')[0])
        if classNumStr == 9: hwLabels.append(-1)
        else: hwLabels.append(1)
        trainingMat[i,:] = img2vector('%s/%s' % (dirName, fileNameStr))
    return trainingMat, hwLabels

def testDigits(kTup=('rbf', 10)):
    dataArr,labelArr = loadImages('trainingDigits')
    b,alphas = smoP(dataArr, labelArr, 200, 0.0001, 10000, kTup)
    datMat=mat(dataArr); labelMat = mat(labelArr).transpose()
    svInd=nonzero(alphas.A>0)[0]
    sVs=datMat[svInd]
    labelSV = labelMat[svInd];
    print "there are %d Support Vectors" % shape(sVs)[0]
    m,n = shape(datMat)
    errorCount = 0
    for i in range(m):
        kernelEval = kernelTrans(sVs,datMat[i,:],kTup)
        predict=kernelEval.T * multiply(labelSV,alphas[svInd]) + b
        if sign(predict)!=sign(labelArr[i]): errorCount += 1
    print "the training error rate is: %f" % (float(errorCount)/m)
    dataArr,labelArr = loadImages('testDigits')
    errorCount = 0
    datMat=mat(dataArr); labelMat = mat(labelArr).transpose()
    m,n = shape(datMat)
    for i in range(m):
        kernelEval = kernelTrans(sVs,datMat[i,:],kTup)
        predict=kernelEval.T * multiply(labelSV,alphas[svInd]) + b
        if sign(predict)!=sign(labelArr[i]): errorCount += 1
    print "the test error rate is: %f" % (float(errorCount)/m)

def plotShow(dataMat,labelMat,b,alphas):
    dataMat=mat(dataMat)
    m=len(labelMat)
    labelMat_copy=[]
    for i in range(m):
        labelMat_copy.append(labelMat[i]+2)
    fig = plt.figure()
    ax = fig.add_subplot(111)
    # draw all samples
    ax.scatter(dataMat[:, 0], dataMat[:, 1], 20.0 * array(labelMat_copy, dtype=float),
               20.0 * array(labelMat_copy, dtype=float))
    # mark support vectors
    supportVectorsIndex=nonzero(alphas.A>0)[0]
    for i in supportVectorsIndex:
        plt.plot(dataMat[i,0],dataMat[i,1],'oy')
     # draw the classify line
    w=zeros((2,1))
    for i in supportVectorsIndex:
        w+=multiply(alphas[i]*labelMat[i],dataMat[i,:].T)
    min_x=min(dataMat[:,0])[0,0]
    max_x=max(dataMat[:,0])[0,0]
    y_min_x=float(-b-w[0]*min_x)/w[1]
    y_max_x=float(-b-w[0]*max_x)/w[1]
    plt.plot([min_x,max_x],[y_min_x,y_max_x],'-g')
    plt.show()

def plotShow1(filename,k1=1.3):
    dataMat, labelMat = loadDataSet(filename)
    b, alphas = smoP(dataMat, labelMat, 200, 0.0001, 1000, ('rbf', k1))
    dataMat=mat(dataMat)
    m=len(labelMat)
    labelMat_copy=[]
    for i in range(m):
        labelMat_copy.append(labelMat[i]+2)
    fig = plt.figure()
    ax = fig.add_subplot(111)
    # draw all samples
    ax.scatter(dataMat[:, 0], dataMat[:, 1], 20.0 * array(labelMat_copy, dtype=float),
               20.0 * array(labelMat_copy, dtype=float))
    # mark support vectors
    supportVectorsIndex = nonzero(alphas.A > 0)[0]
    for i in supportVectorsIndex:
        plt.plot(dataMat[i, 0], dataMat[i, 1],'ob')
    plt.show()


if __name__=='__main__':
    # dataMat,labelMat=loadDataSet('testSet.txt')
    #
    # # b,alphas=smoSimple(dataMat,labelMat,0.6,0.001,40)
    # b,alphas=smoP(dataMat,labelMat,1,0.001,100)
    # print b
    # print alphas[alphas>0]
    # print shape(alphas[alphas>0])
    # for i in range(len(dataMat)):
    #     if alphas[i]>0.0:
    #         print dataMat[i],labelMat[i]
    # plotShow(dataMat,labelMat,b,alphas)
    # testRbf(1.5)
    # plotShow1('testSetRBF.txt')
    testDigits()
