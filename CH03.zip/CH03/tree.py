# -*- coding:utf-8 -*-
# decision tree learning
from math import log
import operator

# Manually create data and labels
def createDataSet():
    dataSet=[[1,1,'yes'],
             [1,1,'yes'],
             [1,0,'no'],
             [0,1,'no'],
             [0,1,'no']]
    labels=['no surfacing','flippers']
    return dataSet,labels

# Computes the information entropy of a given data set
def calacShannonent(dataSet):
    numEntries=len(dataSet) # obtain the number of dataSet
    labelCount={} # labels list
    for featVec in dataSet:
        currentLabel=featVec[-1] # the labels of dataSet
        # if currentLabel not in labelCount.keys():
        #     labelCount[currentLabel]=0
        # labelCount[currentLabel]+=1
        labelCount[currentLabel]=labelCount.get(currentLabel,0)+1
        # computing the number of all labels
    shannonEnt=0.0 # the entropy of dataset
    for key in labelCount:
        prob=float(labelCount[key])/numEntries
        shannonEnt-=prob*log(prob,2) #Shannon formula
    return shannonEnt

# Splitting the data set, picking the desired data set, and removing the data feature
def splitDataSet(dataSet,axis,value):
    retDataSet=[]
    for featVec in dataSet:
        if featVec[axis]==value:
            reducedFeatVec=featVec[:axis]
            reducedFeatVec.extend(featVec[axis+1:]) # removing the data feature
            retDataSet.append(reducedFeatVec) # picking the desired data set
    return retDataSet


# Pick the best feature vector,which the entropy is best
def chooseBestFeatureToSplit(dataSet):
    numFeatures=len(dataSet[0])-1
    baseEntropy=calacShannonent(dataSet)
    bestInfoGain=0.0 # Maximum information gain
    bestFeature=-1
    for i in range(numFeatures):
        featList=[example[i] for example in dataSet]
        uniqueVals=set(featList) # obtain the labels
        newEntropy=0.0
        for value in uniqueVals: # which value of feature vector
            subDataSet=splitDataSet(dataSet,i,value) # pick the subdata ,which is mean of the value
            prob=len(subDataSet)/float(len(dataSet)) # The probability of a subset
            newEntropy+=prob*calacShannonent(subDataSet) # Entropy after splitting
        infoGain=baseEntropy-newEntropy # information gain--Difference between the two entropy
        if infoGain>bestInfoGain:
            bestFeature=i # the best feature vector
            bestInfoGain=infoGain
    return bestFeature


# Get the most number of labels in the leaf node as the label of the node
def majorityCnt(classlist):
    classCount={}
    for vote in classlist:
        classCount[vote]=classCount.get(vote,0)+1 # compute the number of all kind of labels
    sortedClassCount=sorted(classCount.items(),key=operator.itemgetter(1),reverse=True) # Sort
    return sortedClassCount[0][0]


# create decision tree(ID3 alogrithm)
def createTree(dataSet,labels):
    classList=[example[-1] for example in dataSet] # obtain the class labels
    if classList.count(classList[0])==len(classList):
        return classList[0]  # Unified label
    if len(dataSet[0])==1:
        return majorityCnt(classList) # There is no feature vector
    bestFeat=chooseBestFeatureToSplit(dataSet) # pick up the best feature
    bestFeatLabel=labels[bestFeat]
    myTree={bestFeatLabel:{}} # decision tree
    del labels[bestFeat]  # delete the feature
    featValues=[example[bestFeat] for example in dataSet]
    uniqueVals=set(featValues) # obtain the value of the feature
    for value in uniqueVals:
        subLabels=labels[:]
        myTree[bestFeatLabel][value]=createTree(splitDataSet(dataSet,bestFeat,value),subLabels)
    return myTree

# Classification of unknown variables
def classify(inputTree,featLabels,testVec):
    firstStr=inputTree.keys()[0] # root decision tree
    secondDict=inputTree[firstStr]
    featIndex=featLabels.index(firstStr) # Gets the index of the label
    for key in secondDict.keys():
        if testVec[featIndex]==key: # only one to run
            # By determining the data type to know whether the leaf node
            if type(secondDict[key]).__name__=='dict':
                classLabel=classify(secondDict[key],featLabels,testVec)
            else:
                classLabel=secondDict[key]
    return classLabel

# store the decision tree,using the pickle module
# dump
def storeTree(inputTree,filename):
    import pickle
    fw=open(filename,'w')
    pickle.dump(inputTree,fw)
    fw.close()


# read the decision tree,using the pickle module
# load
def grabTree(filename):
    import pickle
    fr=open(filename)
    return pickle.load(fr)

if __name__ == '__main__':
    myData,labels=createDataSet()
    labelss=labels[:]
    print myData
    print calacShannonent(myData)
    # myData[0][-1]='maybe'
    # print myData
    # print calacShannonent(myData)
    # recdata=splitDataSet(myData,0,1)
    # print recdata
    # print chooseBestFeatureToSplit(myData)
    myTree=createTree(myData,labels)
    storeTree(myTree,'classifierStorage.txt')
    print classify(myTree, labelss, [1, 0])

