# -*- coding:utf-8 -*-
# plot the decision tree on the graph
import tree
import matplotlib.pyplot as plt

decisionNode=dict(boxstyle='sawtooth',fc="0.8")
leafNode=dict(boxstyle="round4",fc="0.8")
arrow_args=dict(arrowstyle="<-")



# obtain the number of Leafs using the
def getNumLeafs(myTree):
    numLeafs=0
    firstStr=myTree.keys()[0] # root decision
    secondDict=myTree[firstStr]
    for key in secondDict.keys():
        # By determining the data type to know whether the leaf node
        if type(secondDict[key]).__name__=='dict':
            numLeafs+=getNumLeafs(secondDict[key])
        else:
            numLeafs+=1
    return numLeafs

# obtain the depth of decision tree
def getTreedepth(myTree):
    maxDepth=0
    firstStr=myTree.keys()[0] # root decision
    secondeDict=myTree[firstStr]
    for key in secondeDict.keys(): # obtain the largest value of the depth all kind of leaf decision
        # By determining the data type to know whether the leaf node
        if type(secondeDict[key]).__name__=='dict':
            thisDepth=1+getTreedepth(secondeDict[key])
        else:
            thisDepth=1
        if thisDepth>maxDepth:
            maxDepth=thisDepth
    return maxDepth

# Draw nodes and branch lines
def plotNode(nodeText,centerPt,parentPt,nodeType):
    createPlot.ax1.annotate(nodeText,xy=parentPt,xycoords='axes fraction',
                           xytext=centerPt,textcoords='axes fraction',
                           va='center',ha='center',bbox=nodeType,arrowprops=arrow_args)
    # Text annotations with specific arrows
    # nodeText:the content of text annotations
    # xy:Annotated places
    # xyText:The place to insert the text
    # bbox:Text box logo
    # arrowprops:Arrow signs

# feature values plot
def plotMidText(cntrPt,parentPt,txtString):
    xMid=(parentPt[0]+cntrPt[0])/2.0
    yMid=(parentPt[1]+cntrPt[1])/2.0
    createPlot.ax1.text(xMid,yMid,txtString)

# plot decision tree
def plotTree(myTree,parentPt,nodeTxt):
    numleafs=getNumLeafs(myTree)
    depth=getTreedepth(myTree)
    firstStr=myTree.keys()[0]
    cntrPt=(plotTree.xOff+(1.0+float(numleafs))/2.0/plotTree.totalW,plotTree.yOff)
    plotMidText(cntrPt,parentPt,nodeTxt)
    plotNode(firstStr,cntrPt,parentPt,decisionNode)
    secondeDict=myTree[firstStr]
    plotTree.yOff=plotTree.yOff-1.0/plotTree.totalD
    for key in secondeDict.keys():
        if type(secondeDict[key]).__name__=='dict':
            plotTree(secondeDict[key],cntrPt,str(key))
        else:
            plotTree.xOff=plotTree.xOff+1.0/plotTree.totalW
            plotNode(secondeDict[key],(plotTree.xOff,plotTree.yOff),cntrPt,leafNode)
            plotMidText((plotTree.xOff,plotTree.yOff),cntrPt,str(key))
    plotTree.yOff=plotTree.yOff+1.0/plotTree.totalD

# create plot
def createPlot(inTree):
    fig = plt.figure(1, facecolor='white')
    fig.clf()  # Clear the figure
    axprops=dict(xticks=[],yticks=[])
    createPlot.ax1 = plt.subplot(111, frameon=False,**axprops) # Create a subview
    plotTree.totalD=float(getTreedepth(inTree))
    plotTree.totalW=float(getNumLeafs(inTree))
    plotTree.xOff=-0.5/plotTree.totalW
    plotTree.yOff=1.0
    plotTree(inTree,(0.5,1.0),'')
    plt.show()

if __name__=='__main__':
    # myData, labels = tree.createDataSet()
    # labelss=labels[:]
    # myTree=tree.createTree(myData,labels)
    # print tree.classify(myTree, labelss, [1, 1])
    # createPlot(myTree)
    # mytree=tree.grabTree('classifierStorage.txt')
    # print mytree
    # createPlot(mytree)
    fr=open('lenses.txt')
    lenses=[inst.strip().split('\t') for inst in fr.readlines()]
    lenseslabels=['age','prescript','astigmatic','tearRate']
    myTree=tree.createTree(lenses,lenseslabels)
    tree.storeTree(myTree,'lenseStore.txt')
    readTree=tree.grabTree('lenseStore.txt')
    createPlot(readTree)

