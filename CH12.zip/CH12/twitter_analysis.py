#coding:utf-8
import twitter
from time import sleep
import re
import FP_growth

# obtain data by twitter api
# these key and secret getting by create myself app
def getLotsOfTweets(searchStr):
    COMSUMER_KEY='XLAbqCxIFZbVlreALKhZWVThY'
    COMSUMER_SECRET='AHcPX0FSNvtyy27obo8hIkcubsBYksJ6WOJZ6DvMgV9vEyKcl9'
    ACCESS_TOKEN_KEY='816645964735729667-X7QocSIhD8Pq9SlEghrsHAAlan6wg5a'
    ACCESS_TOKEN_SECRET='hout5DujnlExsDwVaP3F6zeMYIhOQBHPbDGVM9inK3TVb'
    api=twitter.Api(consumer_key=COMSUMER_KEY,
                    consumer_secret=COMSUMER_SECRET,
                    access_token_key=ACCESS_TOKEN_KEY,
                    access_token_secret=ACCESS_TOKEN_SECRET)
    resultsPages=[]
    for i in range(1,15):
        print "fecthing page %d" % i
        searchResults=api.GetSearch(searchStr,count=100,since_id=i)
        resultsPages.append(searchResults)
        sleep(6)
    return resultsPages

# Data initialization, URL removal, and splitting
def textParse(bigString):
    urlsRemoved=re.sub('(http[s]?:[/][/]|www.)([a-z]|[A-Z]|[0-9]|[/.]|[-])*','',bigString)  # URL removal
    listOfTokens=re.split(r'\W*',urlsRemoved)  # splitting
    return [tok.lower() for tok in listOfTokens if len(tok)>2]


# Look for frequent itemsets by calling FP-growth
# tweetArr:data by getLotsOfTweets()
def mineTweets(tweetArr,minSup=5):
    parsedList=[]
    for i in range(14):
        for j in range(100):
            parsedList.append(textParse(tweetArr[i][j].text)) #data deal with
    initSet=FP_growth.createInitSet(parsedList)  # #data deal with
    myTree,myHead=FP_growth.createTree(initSet,minSup)   # create FP tree
    myFreqList=[]
    FP_growth.mineTree(myTree,myHead,minSup,set([]),myFreqList)  # find FP Condition tree
    return myFreqList

if __name__=="__main__":
    # lotsOtweets=getLotsOfTweets('weather')
    # myFreqList=mineTweets(lotsOtweets)
    # print myFreqList
    parseDat=[line.split() for line in open('kosarak.dat')]
    initset=FP_growth.createInitSet(parseDat)
    myTree, myHead = FP_growth.createTree(initset, 100000)
    myFreqList=[]
    FP_growth.mineTree(myTree,myHead,100000,set([]),myFreqList)
    print len(myFreqList)
    print myFreqList