# coding:utf-8
# FP-growth for find all the frequent itemsets

# create data analysis
def loadSimpDat():
    simpDat = [['r', 'z', 'h', 'p'],
               ['z', 'y', 'x', 'w', 'v', 'u', 't', 's'],
               ['z'],
               ['r', 'x', 'n', 'o', 's'],
               ['y', 'r', 'x', 'z', 'q', 't', 'p'],
               ['y', 'z', 'x', 'e', 'q', 's', 't', 'm']]
    return simpDat


# Data initialization
def createInitSet(dataSet):
    retDict = {}
    for trans in dataSet:
        retDict[frozenset(trans)] = 1
    return retDict


# The class definition of the FP tree
# create node to save item set
class treeNode:
    def __init__(self, nameValue, numOccur, parentNode):
        self.name = nameValue  # name of Item set element
        self.count = numOccur  # count of item set element
        self.nodeLink = None  # parent of item set element,Horizontal link
        self.parent=parentNode  # Vertical link
        self.children = {}  # children of item set element,Vertical link

    def inc(self, numOccur):  # update the count of its item set element
        self.count += numOccur

    def disp(self, ind=1):  # print the tree ,which item set element as root
        print  '--' * ind, self.name, '-->', self.count  # '  '*ind as '**'*2='****'
        for child in self.children.values():
            child.disp(ind + 1)


# create fp tree for each data in dataSet
def createTree(dataSet, minSup=1):
    headerTable = {}  # Head pointer table
    # Traversing the data set for the first time,find the frequent single elements
    for trans in dataSet:  # the count of elements,
        for item in trans:
            headerTable[item] = headerTable.get(item, 0) + dataSet[trans]
            # headerTable[item]=headerTable.get(item,0)+1
    for k in headerTable.keys():  # deletes elements that do not meet minimum support
        if headerTable[k] < minSup:
            del headerTable[k]
    freqItemSet = set(headerTable.keys())  # A set of item set elements satisfying the minimum support
    if len(freqItemSet) == 0: return None, None
    for k in headerTable:
        headerTable[k] = [headerTable[k], None]  # update headerTable
    retTree = treeNode('Null Set', 1, None)  # FP tree,initialization
    # The second time to traverse the data set, build FPtree
    for tranSet, count in dataSet.items():  # Build the FPtree in the data order of the dataset
        localD = {}  # Record the data in the elements, sort, build FP tree
        for item in tranSet:
            if item in freqItemSet:
                localD[item] = headerTable[item][0]  # Record the data in the elements
        if len(localD) > 0:
            orderedItems = [v[0] for v in
                            sorted(localD.items(), key=lambda p: p[1], reverse=True)]  # sort,treeNode.name
            updateTree(orderedItems, retTree, headerTable, count)  # build FP tree, count:data count,usually is 1
    return retTree, headerTable


# update tree under a new data
# items[0]:treeNode.name
# The elements in the data are not repeatable
def updateTree(items, inTree, headerTable, count):
    if items[0] in inTree.children:  # tree include the element
        inTree.children[items[0]].inc(count)
    else:  # tree without include the element
        inTree.children[items[0]] = treeNode(items[0], count, inTree)  # create a new branch
        if headerTable[items[0]][1] == None:
            headerTable[items[0]][1] = inTree.children[items[0]]  # create the first node link
        else:
            updateHeader(headerTable[items[0]][1], inTree.children[items[0]])
    if len(items) > 1:
        updateTree(items[1::], inTree.children[items[0]], headerTable, count)  # continue another element for fp tree


# Update links for similar nodes
def updateHeader(nodeToTest, targetNode):
    while (nodeToTest.nodeLink != None):
        nodeToTest = nodeToTest.nodeLink
    nodeToTest.nodeLink = targetNode

""""These are the steps to build an FP tree"""


# gets the prefix path ending with an leafNode, save to prefixPath
def ascendTree(leafNode,prefixPath):
    if leafNode.parent!=None:
        prefixPath.append(leafNode.name)
        ascendTree(leafNode.parent,prefixPath)  # Get the parent link recursively


# # gets the prefix path ending with an element(all leafNode,which is equal to name(element)), save to condPats
# basePat doesn't play a role in it
def findPrefixPath(basePat,treeNode):
    condPats={}
    while treeNode!=None:
        prefixPath=[]
        ascendTree(treeNode,prefixPath)
        if len(prefixPath)>1:  # Determine whether only the root node
            condPats[frozenset(prefixPath[1:])]=treeNode.count # leaf node.count
        treeNode=treeNode.nodeLink # toggle leaf nodes,which node.name is same
    return condPats  # Returns a dictionary containing all conditional pattern bases

# The FP condition tree is constructed to find frequent item sets
def mineTree(inTree,headerTable,minSup,preFix,freqItemList):
    # The elements are sorted by frequency, v[0]=element.name  v[1]=element.count
    bigL=[v[0] for v in sorted(headerTable.items(),key=lambda p:p[1])]
    for basePat in bigL:  # first single elements for frequent item sets,as 't'
        newFreqSet=preFix.copy()
        newFreqSet.add(basePat) #first 't' ,then 'rz','xt','yt',finally 'xyt','xzt'...
        freqItemList.append(newFreqSet)  # List of frequent item sets
        condPattBases=findPrefixPath(basePat,headerTable[basePat][1])  # getting prefixpath,which like dataSet
        myCondTree,myHead=createTree(condPattBases,minSup)  # create FP Condition tree,the baseset value is the largest,The higher the value, the higher the position
        if myHead!=None:
            mineTree(myCondTree,myHead,minSup,newFreqSet,freqItemList)



if __name__ == '__main__':
    # rootNode=treeNode('pyramid',9,None)
    # rootNode.children['eye']=treeNode('eye',13,None)
    # rootNode.disp(12)
    simpDat = loadSimpDat()
    dataSet = createInitSet(simpDat)
    myTree, headerTable = createTree(dataSet, 3)
    print headerTable
    # print headerTable['x'][1]
    # myTree.disp()
    freqItems=[]
    mineTree(myTree,headerTable,3,set([]),freqItems)
    # print freqItems
